import React from 'react';
import UsersList from './components/usersList/UsersList'; // Adjust the path if necessary

function App() {
  return (
    <div className="App">
      <UsersList />
    </div>
  );
}

export default App;
