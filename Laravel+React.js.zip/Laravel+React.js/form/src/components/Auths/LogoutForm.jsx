
import React, { useState } from 'react';
import axios from 'axios';
import './FormStyles.css'; // Import the CSS file for styling

const LogoutForm = () => {
  const [success, setSuccess] = useState(null);
  const [error, setError] = useState(null);

  const handleLogout = async () => {
    try {
      await axios.post('http://127.0.0.1:8000/api/logout', {}, { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` } });
      setSuccess('Logout successful');
      setError(null);
    } catch (error) {
      setError(error.response?.data?.message || 'An error occurred');
      setSuccess(null);
    }
  };

  return (
    <div className="form-container">
      <h2>Logout</h2>
      {success && <div className="success-message">{success}</div>}
      {error && <div className="error-message">{error}</div>}
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default LogoutForm;
