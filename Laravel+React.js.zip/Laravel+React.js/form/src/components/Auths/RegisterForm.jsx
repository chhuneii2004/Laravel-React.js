import React, { useState } from 'react';
import axios from 'axios';
import './FormStyles.css'; // Import the CSS file for styling

const RegisterForm = ({ onUserRegistered }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    password_confirmation: '',
  });
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/register', formData);
      setSuccess(response.data.message);
      setError(null);
      onUserRegistered(response.data.data.user); // Notify parent about new user
    } catch (error) {
      setError(error.response?.data?.message || 'An error occurred');
      setSuccess(null);
    }
  };

  return (
    <div className="form-container">
      <h2>Register</h2>
      {success && <div className="success-message">{success}</div>}
      {error && <div className="error-message">{error}</div>}
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        </label>
        <label>
          Email:
          <input type="email" name="email" value={formData.email} onChange={handleChange} required />
        </label>
        <label>
          Password:
          <input type="password" name="password" value={formData.password} onChange={handleChange} required />
        </label>
        <label>
          Confirm Password:
          <input type="password" name="password_confirmation" value={formData.password_confirmation} onChange={handleChange} required />
        </label>
        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default RegisterForm;
