<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
        }
        .register-card {
            max-width: 450px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        .register-card h1 {
            font-weight: 700;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            position: relative;
            margin-bottom: 20px;
        }
        .form-control {
            height: 45px;
            padding-left: 45px;
            border-radius: 30px;
        }
        .input-icon {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            color: #6c757d;
        }
        .btn-primary {
            width: 100%;
            padding: 10px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 16px;
        }
        .text-center a {
            color: #007bff;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="register-card">
        <h1>Register</h1>
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <i class="bi bi-person input-icon"></i>
                <input type="text" class="form-control" id="name" name="name" placeholder="Name" required>
            </div>
            
            <div class="form-group">
                <i class="bi bi-envelope input-icon"></i>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
            </div>
            
            <div class="form-group">
                <i class="bi bi-lock input-icon"></i>
                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
            </div>
            
            <div class="form-group">
                <i class="bi bi-lock-fill input-icon"></i>
                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm Password" required>
            </div>
            
            <button type="submit" class="btn btn-primary">Register</button>
        </form>
        <p class="text-center mt-3">Already have an account? <a href="<?php echo e(route('login')); ?>">Login here</a>.</p>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\Dev\Desktop\user_login_form\user_login\resources\views/register.blade.php ENDPATH**/ ?>